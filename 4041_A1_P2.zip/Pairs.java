/**
 * Created by peter on 10/11/2017.
 */
public class Pairs {
    //to match the letters and their #s of occurences
    private int occurence = -1;
    private String letter = "";
    public Pairs (String let, int occ) {
        occurence = occ;
        letter = let;
    }
    public int getOccurence() {
        return occurence;
    }
    public void setOccurence(int o) {
        occurence = o;
    }
    public void setLetter(String l) {
        letter = l;
    }
    public String getLetter() {
        return letter;
    }
    public void occur() {
        occurence++;
    }
}
