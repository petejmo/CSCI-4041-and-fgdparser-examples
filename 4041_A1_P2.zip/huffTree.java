/**
 * Created by peter on 10/11/2017.
 */
public class huffTree {
    Pairs[] startArr = null;
    Node primaryNode = null;
    public huffTree(Pairs[] sa) {
        startArr = sa;
    }


    public Node huffenize() {
        Node[] nodeArr = new Node[startArr.length];     //a collection of nodes used to assemble tree
        for (int i = 0; i < startArr.length; i++) {
            nodeArr[i] = new Node(startArr[i]);
        }
        while (!Node.isOneNodeLeft(nodeArr)) {  //while there isn't just a head node (which means complete tree)
            int j = 0;
            Node min = null;
            Node min2 = null;
            int min2Index = -1000000000;     //record which nodes in the array to delete after they're added to tree
            int minIndex = -1000000000;
            while (j < nodeArr.length) {
                if (min2 == null || nodeArr[j].pair.getOccurence() < min2.pair.getOccurence()) {
                    if (min == null || nodeArr[j].pair.getOccurence() < min.pair.getOccurence()) {
                        min2Index = minIndex;
                        min2 = min;
                        min = nodeArr[j];
                        minIndex = j;
                    } else {
                        min2 = nodeArr[j];
                        min2Index = j;
                    }
                }
                j++;
                while (j < nodeArr.length && nodeArr[j] == null) {
                    j++;
                }
            }
            nodeArr[minIndex] = new Node (new Pairs("", min.pair.getOccurence() + min2.pair.getOccurence()));
            //new head created with the two minimum node occurrences added and no letter
            //goes in place of old minimum
            nodeArr[minIndex].leftNode = min;      //left and right children are minimum values
            nodeArr[minIndex].rightNode = min2;
            nodeArr[min2Index] = null;  //deletes node so nodeArr decrements elements
        }
        boolean found = false;
        Node head =  null;
        for (int k = 0; k < nodeArr.length && !found; k++) {     //returns the final node
            if (nodeArr[k] != null) {
                head = nodeArr[k];
                found = true;
            }
        }
        primaryNode = head;
        return head;
    }
    public static void printTree (Node A) {
        System.out.println(A.pair.getLetter() + " " + A.pair.getOccurence());
        if (A.leftNode == null) {
            if (A.rightNode == null) {
                return;
            }else {
                printTree(A.rightNode);
            }
        }else {
            if (A.rightNode == null) {
                printTree(A.leftNode);
            }else {
                printTree(A.leftNode);
                printTree(A.rightNode);
            }
        }
    }
}
