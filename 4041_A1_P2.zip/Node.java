/**
 * Created by peter on 10/11/2017.
 */
public class Node {
    //simple node class with left and right nodes for tree formation
    public Pairs pair = null;
    public Node rightNode = null;
    public Node leftNode = null;

     public Node (Pairs p) {
         pair = p;
     }

    public boolean hasRight() {
        if (rightNode != null) {
            return true;
        }else {
            return false;
        }
    }
    public boolean hasLeft() {
        if (leftNode != null) {
            return true;
        }else {
            return false;
        }
    }
    public static boolean isOneNodeLeft(Node[] a) {
        int count = 0;
        boolean bool = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i] != null) {
                count++;
            }
        }
        if (count == 1) {
            bool = true;
        }
        return bool;
    }
}
