import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Created by peter on 10/11/2017.
 */
public class Main {

    public static String[] stringArr = new String[27];      //records Huffman code for each letter


    public static void main(String[] args) {
        String inputFile = args[args.length-1];
        String mainStr = read(inputFile);
        Pairs[] pairsArr = new Pairs[27];
        int index = -1;
        int elements = 0;
        int i = 0;


        while (i < mainStr.length()) {     //puts Pairs in pairsArr and records occurences of letters
            index = Character.getNumericValue(mainStr.charAt(i)) - 9;
            if (pairsArr[index] == null) {
                pairsArr[index] = new Pairs(String.valueOf(mainStr.charAt(i)), 1);
                elements++;
            }else {
                pairsArr[index].occur();
            }
            i++;
        }

        Pairs[] condensedArray = new Pairs[elements];
        int k = 0;
        for (int j = 1; j < pairsArr.length; j++) {     //eliminates null spaces from array
            if (pairsArr[j] != null) {
                condensedArray[k] = pairsArr[j];
                k++;
            }
        }

        huffTree mainTree = new huffTree(condensedArray);
        Node main = mainTree.huffenize();               //creates Huffman tree from array data


        finish(main, 0, 0);                 //uses Huffman tree to create code

        write("output.txt");

    }
    public static void finish(Node A, int lefts, int rights) {
        if (A.pair.getLetter() != "") {
            //finalStr+= A.pair.getLetter() + ": ";
            stringArr[Character.getNumericValue(A.pair.getLetter().charAt(0)) - 9] = A.pair.getLetter() + ": ";
            for (int i = 0; i < lefts; i++) {
                //finalStr+="0";
                stringArr[Character.getNumericValue(A.pair.getLetter().charAt(0)) - 9] += "0";
            }
            for (int j = 0; j <rights; j++) {
                //finalStr+="1";
                stringArr[Character.getNumericValue(A.pair.getLetter().charAt(0)) - 9] +="1";
            }
            //finalStr+= "\n";
            stringArr[Character.getNumericValue(A.pair.getLetter().charAt(0)) - 9] += "\n";
        }else if (A.leftNode != null) {
            if (A.rightNode != null) {
                finish(A.leftNode, lefts + 1, rights);
                finish(A.rightNode, lefts, rights+ 1);
            }else {
                finish(A.leftNode, lefts+ 1, rights);
            }
        }else {
            finish(A.rightNode, lefts,rights + 1);
        }
    }

    public static String read(String fileName){
        Scanner s = null;
        String resultStr = "";

        try{
            s = new Scanner(new File(fileName));


        }catch (Exception e){
            System.out.println("Couldn't find that file name");
        }

        if (s.hasNext()) {
            resultStr = s.nextLine();
        }
        while (s.hasNext()){
            resultStr += "\n" + s.nextLine();

        }
        return resultStr;

    }

    public static boolean write(String fileName){
        PrintWriter p = null;

        try{
            p = new PrintWriter(new File(fileName));
        } catch (Exception e) {

        }
        boolean firstEntered = false;   //used to get spacing right when printed

        for (int j = 0; j < stringArr.length; j++) {        //writes from array in order
            if (stringArr[j] != null) {
                if (firstEntered) {
                    p.println();
                }
                firstEntered = true;
                p.print(stringArr[j]);
            }
        }
        p.close();

        return true;

    }
}
