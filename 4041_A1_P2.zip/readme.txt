In the zip, there should be this file, "run.sh", "huffTree.java", "Pairs.java", 
"Node.java", and "Main.java."

Extract these files to a directory, and then navigate to the directory in terminal. 
To run, you can try giving "run.sh" permissions and then running "./run.sh input.txt" 
where "input.txt" is replaced with whatever input file you'd like.

However, I had an issue getting the "run.sh" file to compile correctly, and I went to office hours at talked to Paris
but we still didn't figure it out. If the run.sh method doesn't work, run "javac Main.java" and then "java Main input.txt". 
Sorry about this inconvenience. I hope this is not a problem.
 

After running "output.txt" will appear in the directory.