import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
@SuppressWarnings("unchecked") //accounts for array of generics; no chance of array receiving non-String so I suppress

/**
 * Created by peter on 10/12/2017.
 */
public class Main {
    public static String[] resultArr;

    public static void main(String[] args) {
        String inputFile = args[args.length-1];
        String readStr = read(inputFile);
        String[] names = readStr.split("[ ]+");
        resultArr = bucketSort(names, 0);   //second argument is for which letter is being sorted for (bc recursion)
        write("output.txt");

    }
    public static String[] bucketSort(String[] A, int n) {

        ArrayList<String>[] buckets = new ArrayList[27];
        for (int i = 0; i < buckets.length; i++) { //instantiates lists
            buckets[i] = new ArrayList<String>();
        }
        for (int i = 0; i <A.length; i++) {            //adds to the array at the corresponding index to letter (a=1...)
            buckets[(getValue(A[i], n))].add(A[i]);
        }
        for (int i = 0; i < buckets.length; i++) {      //loops for insertion sort on each bucket
            if (buckets[i].size() >10) {                //recursion case for if bucket contains over 10
                String[] temp2 = new String[buckets[i].size()];
                String[] temp = buckets[i].toArray(temp2);
                temp = bucketSort(temp, n+1);
                buckets[i] = new ArrayList<>();
                for (int j = 0; j < temp.length; j++) {
                    buckets[i].add(temp[j]);
                }
            }

            insertionSort(buckets[i]);
        }
        return concatenate(buckets);
    }


    public static int getValue(String str, int n) {
        return Character.getNumericValue(str.toLowerCase().charAt(n)) - 9;
    }
    public static void insertionSort(List<String> A) { //typical insertion sort, referred to Wiki insertion sort page
        for (int i = 0; i <A.size(); i++) {
            int j = i;
            while (j > 0 && !stringCompare(A.get(j-1), A.get(j))) {
                String temp = A.get(j - 1);
                A.set(j-1, A.get(j));
                A.set(j, temp);
                j--;
            }
        }
    }
    public static boolean stringCompare(String a, String b) { //returns true if a<b
        for (int i = 1; i < a.length() && i < b.length();i++) {
            if (getValue(a, i) < getValue(b, i)) {
                return true;
            } else if (getValue(a, i) > getValue(b, i)) {
                return false;
            }
            if (i + 1 >= a.length() || i + 1 >= b.length()) {
                return i + 1 >= a.length();
            }
        }
        return true;
    }
    public static String[] concatenate(ArrayList[] C) { //concatenates buckets together
        ArrayList<String> resultList = new ArrayList<String>();
        for (int i = 0; i < C.length; i++) {
            resultList.addAll(C[i]);
        }
        String[] temp = new String[resultList.size()];
        return resultList.toArray(temp);
    }

    public static String read(String fileName){
        Scanner s = null;
        String resultStr = "";

        try{
            s = new Scanner(new File(fileName));


        }catch (Exception e){
            System.out.println("Couldn't find that file name");

        }
        if (s.hasNext()) {
            resultStr = s.nextLine();
        }
        while (s.hasNext()){
            resultStr += "\n" + s.nextLine();

        }
        return resultStr;

    }

    public static boolean write(String fileName){

        PrintWriter p = null;

        try{
            p = new PrintWriter(new File(fileName));

        } catch (Exception e) {

        }
        for (int i = 0; i < resultArr.length; i++) {
            p.print(resultArr[i]);
            if (i + 1 != resultArr.length) {
                p.print(" ");
            }
        }
        p.close();

        return true;

    }

}
