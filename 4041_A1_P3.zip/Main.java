import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;


/**
 * Created by peter on 10/12/2017.
 */
public class Main {

    public static int result;

    public static void main(String[] args) {
        String inputFile = args[args.length-1];
        String mainString =  read(inputFile);
        Scanner s = new Scanner(mainString);
        int i = s.nextInt();            //records i
        mainString = mainString.substring(2); //retrieves array data to search
        String[] tokens = mainString.split("[ ]+");

        int[] mainArr = new int[tokens.length + 1];
        for (int j = 0; j < tokens.length; j++) {   //gets data into an array
            mainArr[j+1] = Integer.parseInt(tokens[j].trim());
        }
        result = randomSelect(mainArr, 1, mainArr.length - 1, i);
        write("output.txt");
    }

    public static int randomSelect(int[] A, int p, int r, int i) { //recursively partitions, stops if partition= element
        randomPartition(A, p, r, i);
        int x = A[r];
        int c = p -1;
        for (int j = p; j < r; j++) {
            if (A[j] <= x) {
                c++;
                int temp = A[c];
                A[c] = A[j];
                A[j] = temp;
            }
        }
        int temp = A[c+1];
        A[c+1] = A[r];
        A[r] = temp;
        if (c - p + 2 == i) {
            return A[c+1];
        }else if (i > c - p + 2) {
            return randomSelect(A, c+2, r, i - (c+1));
        }else {
            return randomSelect(A, p, c, i);
        }
    }
    public static void randomPartition(int[] A, int p, int r, int i) { //returns random partition and places it at end
        int pivotLoc = p + (int)(Math.random() * ((r - p) + 1));
        int temp = A[r];
        A[r] = A[pivotLoc];
        A[pivotLoc] = temp;
    }

    public static String read(String fileName){
        Scanner s = null;
        String resultStr = "";

        try{
            s = new Scanner(new File(fileName));


        }catch (Exception e){
            System.out.println("Couldn't find that file name");

        }
        if (s.hasNext()) {
            resultStr = s.nextLine();
        }
        while (s.hasNext()){
            resultStr += "\n" + s.nextLine();

        }
        return resultStr;

    }

    public static boolean write(String fileName){

        PrintWriter p = null;

        try{
            p = new PrintWriter(new File(fileName));
        } catch (Exception e) {

        }
        p.println(result);
        p.close();

        return true;

    }

}
